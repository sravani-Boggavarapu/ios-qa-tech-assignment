//
//  ReachNewsUITests.swift
//  ReachNewsUITests
//
//  Created by Gabriel Nica on 14/02/2023.
//  Copyright © 2023 Reach Plc. All rights reserved.
//

import XCTest

final class ReachNewsUITests: XCTestCase {
    
    var app: XCUIApplication!
    
    override func setUp() {
        super.setUp()
        continueAfterFailure = false
        app = XCUIApplication()
        app.launchArguments.append("--uitesting")
        app.launch()
    }
    
    //Test that the app correctly displays a list of 20 articles
    func testDisplayListOfArticles() {
        let tableView = app.tables["newsListTable"]
        
        // Wait for the table view to appear
        let exists = NSPredicate(format: "exists == true")
        expectation(for: exists, evaluatedWith: tableView, handler: nil)
        waitForExpectations(timeout: 10, handler: nil)
        
        XCTAssertEqual(tableView.cells.count, 15, "Expected 15 articles in the list view as per mocked json")
    }
    
    
    //Test that sorting alphabetically by headline works as expected
    func testSortingArticlesByHeadline() {
        let tableView = app.tables["newsListTable"]
        
        // Wait for the table view to appear
        let exists = NSPredicate(format: "exists == true")
        expectation(for: exists, evaluatedWith: tableView, handler: nil)
        waitForExpectations(timeout: 10, handler: nil)
        
        // Sort by headline
        app.navigationBars["Top Stories"].buttons["Sort"].tap()
        app.buttons["Alphabetically By Title"].tap()
        
        // Wait briefly for the UI to update
        sleep(1)
        
        // Verify that all items are sorted alphabetically by headline
        var previousHeadline: String?
        for i in 0..<tableView.cells.count {
            let cell = tableView.cells.element(boundBy: i)
            let headlineLabel = cell.staticTexts["headlineLabel"]
            XCTAssertTrue(headlineLabel.exists, "Cell \(i) should have a headline label")
            let headline = headlineLabel.label
            
            if let previous = previousHeadline {
                XCTAssertTrue(previous.localizedCompare(headline) == .orderedAscending, "Headlines should be sorted alphabetically. '\(previous)' should be before '\(headline)'.")
            }
            previousHeadline = headline
        }
    }
    
    
    func testBookmarkingArticle() {
        
        let tableView = app.tables["newsListTable"]
        
        // Wait for the table view to appear
        let exists = NSPredicate(format: "exists == true")
        expectation(for: exists, evaluatedWith: tableView, handler: nil)
        waitForExpectations(timeout: 10, handler: nil)
        
        // Get the first article cell
        let firstCell = tableView.cells.element(boundBy: 0)
        XCTAssertTrue(firstCell.exists, "First article cell should exist")
        
        // Determine the initial state of the bookmark button
        let addBookmarkButton = firstCell.buttons["addBookmarkButton"]
        let removeBookmarkButton = firstCell.buttons["removeBookmarkButton"]
        
        var initiallyBookmarked: Bool
        if addBookmarkButton.exists {
            initiallyBookmarked = false
            addBookmarkButton.tap()
        } else if removeBookmarkButton.exists {
            initiallyBookmarked = true
            removeBookmarkButton.tap()
        } else {
            XCTFail("Neither addBookmarkButton nor removeBookmarkButton exists")
            return
        }
        
        // Wait briefly for the UI to update
        sleep(1)
        
        // Verify the new state of the bookmark button
        if initiallyBookmarked {
            XCTAssertTrue(firstCell.buttons["addBookmarkButton"].exists, "Bookmark button should be in the add state")
        } else {
            XCTAssertTrue(firstCell.buttons["removeBookmarkButton"].exists, "Bookmark button should be in the remove state")
        }
        
    }
    
    func testSortingArticlesByBookmarkedState() {
        let tableView = app.tables["newsListTable"]
        
        // Wait for the table view to appear
        let exists = NSPredicate(format: "exists == true")
        expectation(for: exists, evaluatedWith: tableView, handler: nil)
        waitForExpectations(timeout: 10, handler: nil)
        
        // Count the initial number of bookmarked articles
        var initialBookmarkedCount = 0
        for i in 0..<tableView.cells.count {
            let cell = tableView.cells.element(boundBy: i)
            if cell.buttons["removeBookmarkButton"].exists {
                initialBookmarkedCount += 1
            }
        }
        
        // Get the first article cell
        let firstCell = tableView.cells.element(boundBy: 0)
        XCTAssertTrue(firstCell.exists, "First article cell should exist")
        
        
        
        // Wait briefly for the UI to update
        sleep(1)
        
        // Sort by bookmarked state
        app.navigationBars["Top Stories"].buttons["Sort"].tap()
        app.buttons["By Bookmarks"].tap()
        
        // Wait briefly for the UI to update
        sleep(1)
        
        // Count the number of bookmarked articles after sorting
        var newBookmarkedCount = 0
        for i in 0..<tableView.cells.count {
            let cell = tableView.cells.element(boundBy: i)
            if cell.buttons["removeBookmarkButton"].exists {
                newBookmarkedCount += 1
            }
        }
        
        
        XCTAssertEqual(newBookmarkedCount, initialBookmarkedCount, "The count of bookmarked articles should be same")
        
        
        // Verify that all bookmarked articles are at the expected positions
        var nonBookmarkedArticlesFound = false
        
        for i in 0..<tableView.cells.count {
            let cell = tableView.cells.element(boundBy: i)
            if cell.buttons["removeBookmarkButton"].exists {
                if nonBookmarkedArticlesFound {
                    XCTFail("Found a bookmarked article after non-bookmarked articles, which indicates incorrect sorting")
                }
                
            } else if cell.buttons["addBookmarkButton"].exists {
                nonBookmarkedArticlesFound = true
            }
        }
    }
    
    
    
    
    //Test that all types are correctly displayed in the list e.g. news, opinion, live
    func testDisplayAllTypes() {
        
        let tableView = app.tables["newsListTable"]
        
        // Wait for the table view to appear
        let exists = NSPredicate(format: "exists == true")
        expectation(for: exists, evaluatedWith: tableView, handler: nil)
        waitForExpectations(timeout: 10, handler: nil)
        
        // Check for the presence of all types
        let newsTypes = ["News", "Opinion", "Live"]
        for i in 0..<tableView.cells.count {
            let cell = tableView.cells.element(boundBy: i)
            let typeLabel = cell.staticTexts["typeLabel"]
            XCTAssertTrue(typeLabel.exists, "Each cell should have a type label")
            XCTAssertTrue(newsTypes.contains(typeLabel.label), "The type label should be one of \(newsTypes)")
        }
    }
    
    
    
    // Detail screen
    func testDetailBookmarkingArticle() {
        
        let articleCell = app.tables["newsListTable"].cells["article0"]
        XCTAssertTrue(articleCell.waitForExistence(timeout: 10), "Failed to find article0 cell")
        articleCell.tap()
        
        sleep(5)
        let bookmarkButton = app.buttons["toggleBookmarkButton"]
        XCTAssertTrue(bookmarkButton.waitForExistence(timeout: 20), "Failed to find toggleBookmarkButton within 20 seconds")
        
        XCTAssertTrue(bookmarkButton.exists)
        
        bookmarkButton.tap()
        XCTAssertEqual(bookmarkButton.label, "Remove From Bookmarks")
        
        bookmarkButton.tap()
        XCTAssertEqual(bookmarkButton.label, "Add To Bookmarks")
    }
    
    func testScrollingThroughArticle() {
        
        let articleCell = app.tables["newsListTable"].cells["article0"]
        XCTAssertTrue(articleCell.waitForExistence(timeout: 10), "Failed to find article0 cell")
        articleCell.tap()
        
        // Wait for the scrollView to appear
        let scrollView = app.scrollViews["articleDetailScrollView"]
        XCTAssertTrue(scrollView.waitForExistence(timeout: 20), "Failed to find articleDetailScrollView within 20 seconds")
        
        // Check if all elements are present
        XCTAssertTrue(app.images["headlineImageView"].exists)
        XCTAssertTrue(app.staticTexts["imageCreditLabel"].exists)
        XCTAssertTrue(app.staticTexts["headlineLabel"].exists)
        XCTAssertTrue(app.staticTexts["bodyLabel"].exists)
        XCTAssertTrue(app.buttons["tagButton"].exists)
        XCTAssertTrue(app.buttons["toggleBookmarkButton"].exists)
        XCTAssertTrue(scrollView.exists)
        
        scrollView.swipeUp()
        scrollView.swipeDown()
    }
    
    func testAllArticlesDisplayImageCredit() {
        let app = XCUIApplication()
        app.launch()
        
        let tableView = app.tables["newsListTable"]
        
        // Wait for the table view to appear
        let exists = NSPredicate(format: "exists == true")
        expectation(for: exists, evaluatedWith: tableView, handler: nil)
        waitForExpectations(timeout: 20, handler: nil)
        
        let cellCount = tableView.cells.count
        XCTAssertGreaterThan(cellCount, 0, "There should be at least one cell in the table view")
        
        for i in 0..<cellCount {
            let cell = tableView.cells.element(boundBy: i)
            XCTAssertTrue(cell.exists, "Cell \(i) should exist")
            cell.tap()
            
            sleep(5)
            // Check for image credit label
            let imageCreditLabel = app.staticTexts["imageCreditLabel"]
            
            
            if imageCreditLabel.exists {
                print("Image credit label exists in article \(i)")
            } else {
                print("Image credit label does not exist in article \(i)")
            }
            XCTAssertTrue(imageCreditLabel.exists, "Image credit label should exist in article \(i)")
            
            let backButton = app.navigationBars.buttons.element(boundBy: 0)
            XCTAssertTrue(backButton.exists, "Back button should exist")
            backButton.tap()
            
            sleep(1)
        }
    }
    
}
