//
//  TableCellSettings.swift
//  ReachNews
//
//  Created by Felipe Scarpitta on 29/09/2022.
//

import UIKit.UITableViewCell

struct TableCellSettings {
    let accessoryType: UITableViewCell.AccessoryType
}
