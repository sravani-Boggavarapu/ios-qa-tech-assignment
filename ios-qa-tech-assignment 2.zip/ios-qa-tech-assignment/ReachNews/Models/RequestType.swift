//
//  RequestType.swift
//  ReachNews
//
//  Created by Felipe Scarpitta on 28/09/2022.
//

import Foundation

enum RequestType: String {
    case get, post, put, delete
}
