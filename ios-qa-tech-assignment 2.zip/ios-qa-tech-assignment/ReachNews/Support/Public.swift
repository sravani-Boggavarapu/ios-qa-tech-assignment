//
//  Public.swift
//  ReachNews
//
//  Created by Felipe Scarpitta on 28/09/2022.
//

import Foundation

func Localized(_ string: String) -> String {
    return NSLocalizedString(string, comment: "")
}
