//
//  MockNewsAPIService.swift
//  ReachNewsTests
//
//  Created by User on 12/07/24.
//  Copyright © 2024 Reach Plc. All rights reserved.
//

import Foundation
@testable import ReachNews


class MockNewsAPIService: NewsAPIService {
    var mockArticles: [Article] = []

    init() {
        if let articles: [Article] = loadJSONFromFile("Articles", type: [Article].self) {
            self.mockArticles = articles
        }
    }

    func getNewsData() async throws -> [Article] {
        return mockArticles
    }
}
    func loadJSONFromFile<T: Decodable>(_ filename: String, type: T.Type) -> T? {
        guard let url = Bundle(for: MockNewsAPIService.self).url(forResource: filename, withExtension: "json"),
              let data = try? Data(contentsOf: url) else {
            return nil
        }

        let decoder = JSONDecoder()
        do {
            let decodedObject = try decoder.decode(T.self, from: data)
            return decodedObject
        } catch {
            print("Error decoding JSON: \(error)")
            return nil
        }
    }

